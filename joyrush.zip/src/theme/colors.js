export const primaryColor = '#6FDA45';
export const lightgray = '#F0F5F8';
export const red = '#c22136';